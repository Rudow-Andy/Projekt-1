#!/usr/bin/env python3
"""
Generates a daily briefing and emails it via Gmail SMTP.

Required env vars (GitHub Secrets):
  GEMINI_API_KEY, RECIPIENT_EMAIL, SMTP_USER, SMTP_PASSWORD
"""

from __future__ import annotations

import os
import json
import datetime as dt
import smtplib
import ssl
import re
import time
from urllib.parse import urlparse
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List, Dict, Any, Optional, Set

from google import genai
from google.genai import types
import markdown as md


# -----------------------------
# Helpers
# -----------------------------

def require_env(name: str) -> str:
    v = os.getenv(name, "").strip()
    if not v:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return v


def today_iso_utc() -> str:
    return dt.datetime.utcnow().strftime("%Y-%m-%d")


def load_json(rel_path: str) -> dict:
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, rel_path)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_config() -> dict:
    return load_json("config.json")


def load_entity_universe(cfg: dict) -> dict:
    here = os.path.dirname(os.path.abspath(__file__))
    rel = (cfg.get("entity_coverage") or {}).get("entity_universe_path", "entity_universe.json")
    path = os.path.join(here, rel)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"states": {}}


def dedup_keep_order(items: List[str]) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in items:
        x = (x or "").strip()
        if not x:
            continue
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def estimate_word_count(text: str) -> int:
    """
    Estimates word count from model text for output-size guardrails.
    """
    return len(re.findall(r"\S+", text or ""))


def extract_markdown_links(markdown_text: str) -> List[str]:
    links = re.findall(r"\[[^\]]+\]\((https?://[^)\s]+)\)", markdown_text or "")
    return dedup_keep_order(links)


def extract_link_quality(markdown_text: str) -> Dict[str, Any]:
    unique_urls = set(extract_markdown_links(markdown_text))
    domains: Set[str] = set()
    for u in unique_urls:
        parsed = urlparse(u)
        host = (parsed.netloc or "").lower()
        if host.startswith("www."):
            host = host[4:]
        if host:
            domains.add(host)
    return {
        "unique_urls": unique_urls,
        "unique_url_count": len(unique_urls),
        "unique_domains": domains,
        "unique_domain_count": len(domains),
    }


def get_citation_thresholds(cfg: dict) -> Dict[str, int]:
    mode = ((cfg or {}).get("briefing_mode", "standard") or "standard").strip().lower()
    quality_cfg = ((cfg or {}).get("model") or {}).get("citation_quality", {}) or {}
    mode_cfg = quality_cfg.get(mode, {}) or {}
    if mode == "compact":
        min_links = int(mode_cfg.get("min_links", 3))
        min_domains = int(mode_cfg.get("min_domains", 2))
    else:
        min_links = int(mode_cfg.get("min_links", 5))
        min_domains = int(mode_cfg.get("min_domains", 3))
    return {"mode": mode, "min_links": min_links, "min_domains": min_domains}


def meets_citation_threshold(markdown_text: str, thresholds: Dict[str, int]) -> Dict[str, Any]:
    stats = extract_link_quality(markdown_text)
    links_ok = stats["unique_url_count"] >= int(thresholds["min_links"])
    domains_ok = stats["unique_domain_count"] >= int(thresholds["min_domains"])
    stats["threshold_passed"] = links_ok and domains_ok
    stats["links_ok"] = links_ok
    stats["domains_ok"] = domains_ok
    stats["min_links"] = int(thresholds["min_links"])
    stats["min_domains"] = int(thresholds["min_domains"])
    return stats


def build_compression_prompt(markdown_text: str, max_words: int) -> str:
    return f"""You are compressing a markdown briefing to satisfy a strict maximum length.

Compression requirements:
1. Preserve ALL section headers and overall section order.
2. Preserve factual claims (entities, dates, numbers, deadlines, commitments).
3. Remove repetition, verbose phrasing, and non-essential filler.
4. Keep markdown citations/links intact where they exist.
5. If any citation cannot be kept inline, include it in a final 'Sources' list.
6. Output must remain valid markdown.
7. Final output must be <= {max_words} words.

Return only the compressed markdown.

--- BEGIN BRIEFING ---
{markdown_text}
--- END BRIEFING ---"""


def is_obviously_retired_model(model_id: str) -> bool:
    """
    Avoid known-retired families like Gemini 1.0/1.5 which commonly return 404.
    """
    m = (model_id or "").strip().lower()
    return ("gemini-1.0" in m) or ("gemini-1.5" in m)


def sanitize_config_models(cfg_models: List[str]) -> List[str]:
    """
    Drops obviously retired model ids, trims whitespace, de-dups.
    """
    cleaned = []
    for m in cfg_models or []:
        m = (m or "").strip()
        if not m:
            continue
        if is_obviously_retired_model(m):
            # skip old/retired ids that cause 404
            continue
        cleaned.append(m)
    return dedup_keep_order(cleaned)


def pick_spotlight_entities(cfg: dict, universe: dict, iso_date: str) -> List[str]:
    cov = cfg.get("entity_coverage", {}) or {}
    k = int(cov.get("spotlight_entities_per_day", 25))
    always = list(dict.fromkeys([e for e in cov.get("always_include", []) if isinstance(e, str) and e.strip()]))

    # Flatten universe into stable list
    flat: List[str] = []
    states = (universe.get("states") or {})
    for state_name in sorted(states.keys()):
        cats = (states[state_name].get("categories") or {})
        for cat_name in sorted(cats.keys()):
            for ent in cats[cat_name]:
                if isinstance(ent, str) and ent.strip():
                    flat.append(ent.strip())

    flat_unique = dedup_keep_order(flat)
    if not flat_unique:
        return always

    seed = sum(ord(ch) for ch in iso_date)
    start = seed % len(flat_unique)

    spotlight: List[str] = []
    i = start
    while len(spotlight) < k and len(spotlight) < len(flat_unique):
        spotlight.append(flat_unique[i])
        i = (i + 1) % len(flat_unique)

    out: List[str] = []
    for e in always + spotlight:
        if e not in out:
            out.append(e)
    return out


# -----------------------------
# System Instruction & Prompt
# -----------------------------

def build_system_instruction(brevity: Dict[str, Any]) -> str:
    """
    System instruction that enforces grounding, format rules, and output structure.
    This is processed with higher priority than the user prompt.
    """
    target_words = brevity.get("target_words", [900, 1200])
    if not isinstance(target_words, list) or len(target_words) != 2:
        target_words = [900, 1200]
    target_min, target_max = int(target_words[0]), int(target_words[1])
    max_words = int(brevity.get("max_words", 1300))
    section_limits = brevity.get("section_word_limits", {}) or {}
    top_priority_limit = int(section_limits.get("top_priority", 80))
    signal_limit = int(section_limits.get("signal", 120))
    regulatory_limit = int(section_limits.get("regulatory_countdown", 220))

    return f"""You are a German public sector business intelligence analyst creating a daily briefing for business development purposes.

CRITICAL RULES (MUST FOLLOW):
1. USE GOOGLE SEARCH for EVERY factual claim. You have access to Google Search - USE IT for every piece of information.
2. ONLY include information you can verify through search. If you cannot find current sources, OMIT the item entirely.
3. DO NOT invent or hallucinate: tenders, budgets, deadlines, leadership changes, projects, or initiatives.
4. DO NOT use your training data for facts - ALWAYS search for current information.
5. Focus on information from the LAST 72 HOURS. Older information should be clearly marked with its date.
6. DO NOT paste raw URLs in the text - citations are handled automatically via grounding metadata.
7. Keep personal data minimal: job titles/roles are OK, but no private emails or phone numbers.
8. Brevity is mandatory: target {target_min}-{target_max} words total, never exceed {max_words} words.
9. Enforce section limits: Top Priority <= {top_priority_limit} words; each Hard Signal block (including table text) <= {signal_limit} words; Regulatory Countdown section <= {regulatory_limit} words.

ZERO-TOLERANCE FOR FABRICATION:
- If Google Search returns no relevant recent results for an entity or topic, DO NOT fill in with generic or outdated information. Simply skip that entity.
- If fewer than 3 verified hard signals exist this week, include only what you found. Writing "No verified signals in this period" for a section is preferable to inventing content.
- Every date, budget figure, contract value, and organizational name MUST come from a search result. If you cannot cite it, do not include it.

ITEM SCORING RUBRIC (APPLY BEFORE INCLUDING ANY CANDIDATE ITEM):
- Score each candidate item on a 0-5 scale for:
  1) Impact on near-term BD opportunity
  2) Urgency/deadline proximity
  3) Verifiability from official sources
- Compute total score out of 15.
- Minimum inclusion threshold: include only items scoring >=10/15.
- If an item scores below threshold, DROP it (do not summarize it in the output).
- A shorter briefing with 2 real signals is far more valuable than a longer briefing with fabricated content.

OUTPUT FORMAT (Markdown - follow this structure EXACTLY):

COMPACT OUTPUT RULES:
- Include ONLY signals backed by sources found via Google Search. Never pad sections with generic or outdated content.
- If fewer than 3 high-confidence developments are available, include only what you found (1 or 2 is fine).
- If NO verified developments exist for a section, write: "No verified signals in this period." — do not invent content.
- Limit bullets per subsection to a maximum of 3.
- Use concise phrasing and single-sentence bullets where possible.
- Section 6 (Capability Quick Reference) is a static reference — fill it from the provided themes without searching.

---

⚡ TODAY'S TOP PRIORITY

**[Key deadline or development with T-X Days countdown if applicable].** [1-2 sentences explaining why this matters and what action to take.]

**Gartner Play:** [Specific positioning recommendation - what to pitch and how.]

---

## 1. VERIFIED HARD SIGNALS

*Confirmed developments requiring immediate BD attention*

### 1.1 [Signal Title with Key Metric if applicable]

| Element | Details |
|---------|---------|
| **Signal** | [What happened - be specific with numbers, dates, entities] |
| **Source** | [Official source and date] |
| **Advisory Opening** | [How to position - specific service/capability to offer, pain point to address] |
| **Gartner Asset** | [Relevant Gartner research, frameworks, or tools to reference] |
| **Decision-Oriented Outcome** | [Concrete decision this enables now, e.g., who to contact this week and why] |

### 1.2 [Next Signal Title]
[Same table structure...]

### 1.3 [Next Signal Title]
[Same table structure...]

---

## 2. REGULATORY COUNTDOWN: [PRIMARY REGULATION]

🚨 **CRITICAL DEADLINE: [Date] (T-X Days)**

[1-2 sentences on what takes effect and implications]

**What Public Sector Agencies Are Missing:**
- [Gap 1]
- [Gap 2]
- [Gap 3]

**Gartner Advisory Positioning:**
- **[Capability Area 1]** — [How to position]
- **[Capability Area 2]** — [How to position]
- **[Capability Area 3]** — [How to position]

*[Any relevant note about upcoming platforms, registries, or requirements]*

---

## 3. STRATEGIC THEME: [THEME NAME]

[2-3 sentence overview of current state and why it matters]

**Verified Developments:**
- [Development 1 with entity and date]
- [Development 2 with entity and date]
- [Development 3 with entity and date]
- **Decision-Oriented Outcome:** [One concrete decision to take this week (owner, target contact, and purpose)]

**Gartner Play:** Position **[specific capabilities]** as core to [objective]. Talk track: [specific talking points].

---

## 4. PRIORITIZED ACTION ITEMS

| Priority | Target | Action | Timing |
|----------|--------|--------|--------|
| **P1** | [Entity] | [Specific action with context + decision-oriented outcome (who to contact this week)] | This Week |
| **P1** | [Entity] | [Specific action with context + decision-oriented outcome (who to contact this week)] | This Week |
| **P2** | [Entity] | [Specific action with context + decision-oriented outcome] | Next 2 Weeks |
| **P2** | [Entity] | [Specific action with context + decision-oriented outcome] | [Quarter] |
| **P3** | [Entity] | [Specific action with context + decision-oriented outcome] | [Quarter] |

---

## 5. CALENDAR: KEY DATES AHEAD

| Date | Event |
|------|-------|
| [Month Year] | [Event description] |
| [Specific Date] | [Event with significance] |
| [Specific Date] | **[MAJOR DEADLINE]** — [Description] |

---

## 6. GARTNER CAPABILITY QUICK REFERENCE

*Match these capabilities to prospect pain points for effective positioning*

| Capability Theme | Key Deliverables |
|------------------|------------------|
| **AI Governance & Compliance** | [Specific deliverables] |
| **Cloud & Infrastructure** | [Specific deliverables] |
| **Procurement & Sourcing** | [Specific deliverables] |
| **Sovereignty & Exit** | [Specific deliverables] |
| **Workforce & Literacy** | [Specific deliverables] |

---

*This briefing is based on verified market signals as of [DATE].*

*Sources: [List key source domains used]*

**For Gartner internal BD use only. Do not distribute externally.**"""


def build_prompt(cfg: dict, brevity: Dict[str, Any]) -> str:
    """
    User prompt with the specific briefing parameters for today.
    """
    today = today_iso_utc()
    day_of_week = dt.datetime.utcnow().strftime("%A")
    lookback = int(cfg.get("lookback_hours", 72))
    briefing_mode = (cfg.get("briefing_mode", "standard") or "standard").strip().lower()
    if briefing_mode not in {"standard", "compact"}:
        briefing_mode = "standard"

    territory = ", ".join(cfg.get("territory", [])) or "[Territory]"
    prepared_for = cfg.get("prepared_for", "[Your Name]")

    universe = load_entity_universe(cfg)
    spotlight = pick_spotlight_entities(cfg, universe, today)
    spotlight_str = ", ".join(spotlight) if spotlight else "(none)"

    brand_title = (cfg.get("brand") or {}).get("title", "GARTNER PUBLIC SECTOR DAILY")
    brand_subtitle = (cfg.get("brand") or {}).get("subtitle", "New Business Intelligence Briefing")

    target_words = brevity.get("target_words", [900, 1200])
    if not isinstance(target_words, list) or len(target_words) != 2:
        target_words = [900, 1200]
    target_min, target_max = int(target_words[0]), int(target_words[1])
    max_words = int(brevity.get("max_words", 1300))
    section_limits = brevity.get("section_word_limits", {}) or {}
    top_priority_limit = int(section_limits.get("top_priority", 80))
    signal_limit = int(section_limits.get("signal", 120))
    regulatory_limit = int(section_limits.get("regulatory_countdown", 220))

    # Build account details
    acct_lines: List[str] = []
    for a in cfg.get("accounts", []):
        name = a.get("name", "Unknown")
        projects = ", ".join(a.get("active_projects_seed", []))
        acct_lines.append(f"- {name}: Active projects/areas: {projects}")
    acct_section = "\n".join(acct_lines) if acct_lines else "- German public sector entities"

    # Build theme details
    theme_lines: List[str] = []
    for t in cfg.get("themes", []):
        name = t.get("name", "Theme")
        seeds = ", ".join(t.get("seed", []))
        theme_lines.append(f"- {name}: {seeds}")
    theme_section = "\n".join(theme_lines) if theme_lines else "- Digital transformation themes"

    # Build regulatory items
    reg_lines: List[str] = []
    for r in cfg.get("regulatory_items", []):
        reg_lines.append(f"- {r.get('name', 'Item')}: {r.get('date', 'TBD')} - {r.get('notes', '')}")
    reg_section = "\n".join(reg_lines) if reg_lines else "- EU AI Act and related regulations"

    # Build capability themes for quick reference
    capability_themes = [
        "AI Governance & Compliance: AI strategy roadmaps, risk frameworks, AI Act alignment, AI model inventory templates, risk assessment playbooks",
        "Cloud & Infrastructure: Landing zone design, FinOps/cost governance, private/hybrid cloud architectures, migration-factory patterns",
        "Procurement & Sourcing: AI contracting guidance, market intelligence, vendor landscape analysis (MQ SCPS), lifecycle SLAs",
        "Sovereignty & Exit: Data residency assessments, sovereign cloud options, exit-strategy planning with trigger documentation",
        "Workforce & Literacy: AI literacy programs, cohort training, CoE setup, model science and AI security skill development"
    ]

    return f"""Generate today's {brand_title}
{brand_subtitle}

**Date:** {today} ({day_of_week})
**Prepared for:** {prepared_for}
**Territory:** {territory}
**Briefing mode:** {briefing_mode}

STEP 1 — SEARCH GOOGLE NOW. Search for each priority entity below individually. Look for:
- Official press releases, procurement notices, tender announcements from the last {lookback} hours
- Budget decisions, policy announcements, leadership changes
- IT/digital strategy updates, contract awards, project milestones
If a search returns no recent relevant results for an entity, move on — do NOT fabricate content for it.

PRIORITY ENTITIES TO RESEARCH:
{acct_section}

ADDITIONAL SPOTLIGHT ENTITIES (search only if time permits after priority entities):
{spotlight_str}

STEP 2 — REGULATORY COUNTDOWN. Verify these items and calculate T-minus days from today {today}:
{reg_section}

STEP 3 — STRATEGIC THEME. Pick ONE theme based on which has the most newsworthy VERIFIED developments right now:
{theme_section}

STEP 4 — GENERATE BRIEFING. Follow the exact format from your system instructions.
- Only include signals backed by sources found in Step 1.
- Section 6 (Capability Quick Reference) is a static reference table — fill it using the themes below without searching:
{chr(10).join('- ' + c for c in capability_themes)}
- If you found fewer than 3 hard signals, include only what you verified. Quality over quantity.
- Include real source domains in the footer (e.g., bmi.bund.de, egovernment.de, kommune21.de).

START THE OUTPUT WITH:
🇩🇪 {brand_title}
{brand_subtitle}

Date: {today} ({day_of_week}) | Prepared for: {prepared_for} | Territory: {territory}"""


# -----------------------------
# Grounding citations handling
# -----------------------------

def add_citations_markdown(response) -> str:
    """
    Inject inline citation links from Gemini grounding metadata.

    NOTE: grounding_metadata / grounding_chunks are frequently empty even when
    Google Search ran successfully — this is a confirmed Gemini API platform bug
    (open as of early 2026). Citations are therefore best-effort. Never block or
    fail a run because this function returns the original text unchanged.
    """
    text = getattr(response, "text", "") or ""
    if not text:
        return text

    # Safely extract grounding metadata — any attribute may be None.
    try:
        candidates = getattr(response, "candidates", None) or []
        cand = candidates[0] if candidates else None
        gm = getattr(cand, "grounding_metadata", None) if cand else None
        supports = getattr(gm, "grounding_supports", None) if gm else None
        chunks = getattr(gm, "grounding_chunks", None) if gm else None
    except Exception as exc:
        print(f"WARN: Failed to read grounding metadata fields: {exc}")
        return text

    if not supports or not chunks:
        if gm is not None:
            # Metadata object exists but is hollow — known Gemini platform bug.
            qs = getattr(gm, "web_search_queries", None)
            print(
                f"WARN: grounding_metadata present but supports/chunks empty "
                f"(web_search_queries={qs!r}). Known Gemini grounding bug — "
                "citations unavailable for this run."
            )
        else:
            print("INFO: No grounding metadata returned; citations unavailable.")
        return text  # Return clean text — no user-visible note appended.

    supports_sorted = sorted(supports, key=lambda s: s.segment.end_index, reverse=True)
    injected = 0
    for support in supports_sorted:
        end_index = support.segment.end_index
        idxs = list(getattr(support, "grounding_chunk_indices", []) or [])
        if not idxs:
            continue

        links = []
        for i in idxs:
            if i >= len(chunks):
                # Hallucinated citation index — confirmed Gemini 2.5 bug.
                print(f"WARN: Citation index {i} out of range (chunks={len(chunks)}); dropping.")
                continue
            if getattr(chunks[i], "web", None):
                uri = chunks[i].web.uri
                links.append(f"[{i+1}]({uri})")
        if not links:
            continue

        cite = " " + ", ".join(links)
        if 0 <= end_index <= len(text):
            text = text[:end_index] + cite + text[end_index:]
            injected += 1

    print(f"INFO: Injected {injected} citation group(s) from grounding metadata.")
    return text


def markdown_to_html(markdown_text: str, footer_note: Optional[str] = None) -> str:
    html = md.markdown(markdown_text, extensions=["extra", "sane_lists", "smarty"], output_format="html5")
    footer_html = ""
    if footer_note:
        footer_html = f"""
    <hr style="border:none;border-top:1px solid #ddd;margin:24px 0;"/>
    <p style="font-size:12px;color:#888;line-height:1.5;">{footer_note}</p>"""
    return f"""\
<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
    <title>Gartner Public Sector Daily</title>
  </head>
  <body style="font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.55;color:#1a1a1a;max-width:800px;margin:0 auto;padding:16px 20px;">
    {html}
    {footer_html}
  </body>
</html>
"""


def ensure_citations_present(markdown_text: str, fallback_citations: List[str]) -> str:
    if not fallback_citations:
        return markdown_text

    has_inline_links = bool(re.search(r"\[[^\]]+\]\((https?://[^)\s]+)\)", markdown_text or ""))
    if has_inline_links:
        return markdown_text

    source_lines = "\n".join(f"- {u}" for u in fallback_citations)
    return f"{markdown_text.rstrip()}\n\n## Sources\n{source_lines}\n"



# -----------------------------
# Email
# -----------------------------

def send_email(subject: str, html_body: str, sender: str, recipients: List[str], smtp_password: str) -> None:
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender, smtp_password)
            server.sendmail(sender, recipients, msg.as_string())
    except smtplib.SMTPAuthenticationError as e:
        raise RuntimeError(
            "Gmail SMTP authentication failed. Verify SMTP_USER and SMTP_PASSWORD "
            f"(must be a Gmail App Password with 2FA enabled, not your account password). "
            f"Detail: {e}"
        ) from e
    except smtplib.SMTPRecipientsRefused as e:
        raise RuntimeError(f"SMTP rejected all recipients {recipients}: {e}") from e
    except smtplib.SMTPException as e:
        raise RuntimeError(f"SMTP error sending to {recipients}: {e}") from e


# -----------------------------
# Model selection + generation
# -----------------------------

class QuotaExceededError(RuntimeError):
    """Raised when Gemini requests fail due to quota / rate-limit exhaustion."""


def summarize_error(exc: Exception) -> str:
    msg = " ".join(str(exc).strip().split())
    return msg[:280] + ("..." if len(msg) > 280 else "")


def is_quota_error(exc: Exception) -> bool:
    msg = str(exc).lower()
    markers = ["resource_exhausted", "429", "too many requests", "quota", "rate limit", "ratelimit"]
    return any(m in msg for m in markers)


def list_available_models(client: genai.Client, limit: int = 40) -> List[str]:
    """
    Best-effort: list available model IDs for debugging in Actions logs.
    """
    out: List[str] = []
    try:
        for m in client.models.list():
            name = getattr(m, "name", None) or getattr(m, "model", None) or ""
            name = str(name)
            # Often "models/..." — strip that for readability
            if name.startswith("models/"):
                name = name[len("models/"):]
            if name:
                out.append(name)
            if len(out) >= limit:
                break
    except Exception:
        return []
    return out


def throttle_gemini_calls() -> None:
    min_interval_sec = float(os.getenv("GEMINI_MIN_INTERVAL_SEC", "12"))
    if min_interval_sec > 0:
        print(f"INFO: Throttling Gemini call for {min_interval_sec:.1f}s")
        time.sleep(min_interval_sec)


def run_preflight_check(client: genai.Client, model_ids: List[str]) -> None:
    """
    Send one tiny request so we can fail fast with a clear reason in logs.
    """
    if not model_ids:
        raise RuntimeError("No model IDs configured for preflight check.")

    model = model_ids[0]
    cfg = types.GenerateContentConfig(
        temperature=0.0,
        max_output_tokens=20,
    )
    try:
        throttle_gemini_calls()
        client.models.generate_content(model=model, contents="Respond exactly with: OK", config=cfg)
        print(f"INFO: Preflight check succeeded with model '{model}'.")
    except Exception as e:
        msg = summarize_error(e)
        print(f"WARN: Preflight check failed on model '{model}': {msg}")
        if is_quota_error(e):
            raise QuotaExceededError(f"Preflight quota/rate-limit failure on '{model}': {msg}") from e
        raise RuntimeError(f"Preflight failed on '{model}': {msg}") from e


def generate_with_fallback(
    client: genai.Client,
    model_ids: List[str],
    prompt: str,
    gen_cfg: types.GenerateContentConfig,
):
    last_err: Optional[Exception] = None
    tried: List[str] = []
    quota_seen = False

    for mid in model_ids:
        try:
            tried.append(mid)
            print(f"INFO: Trying model='{mid}' max_output_tokens={gen_cfg.max_output_tokens}")
            throttle_gemini_calls()
            return client.models.generate_content(model=mid, contents=prompt, config=gen_cfg)
        except Exception as e:
            last_err = e
            quota_seen = quota_seen or is_quota_error(e)
            print(f"WARN: Model '{mid}' failed: {summarize_error(e)}")

    # If everything failed, print available models (helps you fix config without guesswork)
    avail = list_available_models(client, limit=40)
    if avail:
        print("DEBUG: Available models (first 40):")
        for x in avail:
            print(f" - {x}")

    err_msg = (
        "All models failed.\n"
        f"Tried: {tried}\n"
        f"Last error: {summarize_error(last_err) if last_err else 'unknown'}"
    )
    if quota_seen:
        raise QuotaExceededError(err_msg)
    raise RuntimeError(err_msg)


def build_quota_alert_html(subject_prefix: str, error_message: str) -> str:
    now_utc = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    return f"""<html>
  <body style="font-family: Arial, Helvetica, sans-serif; line-height: 1.45;">
    <h2>{subject_prefix} — quota/rate-limit alert</h2>
    <p>The daily briefing run could not complete due to Gemini API quota/rate limits.</p>
    <ul>
      <li><strong>Time:</strong> {now_utc}</li>
      <li><strong>Reason:</strong> {error_message}</li>
      <li><strong>Action needed:</strong> Enable billing or increase Gemini API quota/rate limits for this project.</li>
    </ul>
    <p>This is an operational fallback email sent by the workflow when content generation is blocked.</p>
  </body>
</html>
"""


def build_length_cap_alert_html(subject_prefix: str, diagnostics: Dict[str, Any]) -> str:
    now_utc = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    return f"""<html>
  <body style="font-family: Arial, Helvetica, sans-serif; line-height: 1.45;">
    <h2>{subject_prefix} — length cap alert</h2>
    <p>The daily briefing exceeded the configured word-count cap even after two compression passes.</p>
    <ul>
      <li><strong>Time:</strong> {now_utc}</li>
      <li><strong>Configured cap:</strong> {diagnostics.get('configured_cap', '?')} words</li>
      <li><strong>Pre-citation words:</strong> {diagnostics.get('pre_citation_words', '?')}</li>
      <li><strong>Post-compression words:</strong> {diagnostics.get('post_compression_words', '?')}</li>
      <li><strong>Final words:</strong> {diagnostics.get('final_words', '?')}</li>
    </ul>
    <p>The briefing email was suppressed. Consider lowering max_output_tokens or tightening brevity targets.</p>
  </body>
</html>
"""



# -----------------------------
# Main
# -----------------------------

def main() -> None:
    cfg = load_config()

    recipient_env = require_env("RECIPIENT_EMAIL")
    smtp_user = require_env("SMTP_USER")
    smtp_password = require_env("SMTP_PASSWORD")

    recipients = [r.strip() for r in recipient_env.split(",") if r.strip()]
    if not recipients:
        raise RuntimeError("RECIPIENT_EMAIL did not contain any valid addresses.")

    model_cfg = cfg.get("model") or {}
    brevity = model_cfg.get("brevity", {}) or {}

    prompt = build_prompt(cfg, brevity)
    citation_thresholds = get_citation_thresholds(cfg)

    # Create client with explicit API key (google-genai SDK looks for GOOGLE_API_KEY by default)
    api_key = require_env("GEMINI_API_KEY")
    client = genai.Client(api_key=api_key)

    # System instruction for strict format and grounding enforcement
    system_instruction = build_system_instruction(brevity)
    print("INFO: Omitted due to low confidence/impact: items below rubric threshold are intentionally excluded.")

    # Google Search grounding tool
    grounding_tool = types.Tool(google_search=types.GoogleSearch())
    base_max_tokens = int((cfg.get("model") or {}).get("max_output_tokens", 3800))
    base_temperature = float((cfg.get("model") or {}).get("temperature", 0.2))
    max_words = int(brevity.get("max_words", 1300))
    print(f"INFO: Effective max_words cap={max_words}")

    # Use only explicitly configured models.
    cfg_models_raw = (cfg.get("model") or {}).get("preferred_models", []) or []
    cfg_models = sanitize_config_models(cfg_models_raw)
    model_ids = dedup_keep_order(cfg_models)
    if not model_ids:
        raise RuntimeError("No non-retired model IDs are configured.")

    primary_cfg = types.GenerateContentConfig(
        system_instruction=system_instruction,
        tools=[grounding_tool],
        temperature=base_temperature,
        top_p=0.95,
        max_output_tokens=base_max_tokens,
    )

    reduced_max_tokens = max(1200, int(base_max_tokens * 0.65))
    reduced_cfg = types.GenerateContentConfig(
        system_instruction=system_instruction,
        tools=[grounding_tool],
        temperature=base_temperature,
        top_p=0.95,
        max_output_tokens=min(reduced_max_tokens, base_max_tokens),
    )

    compression_cfg = types.GenerateContentConfig(
        system_instruction="You are an expert editor. Follow compression instructions exactly.",
        temperature=0.0,
        top_p=0.9,
        max_output_tokens=base_max_tokens,
    )

    subject_prefix = (cfg.get("email") or {}).get("subject_prefix", "Public Sector Intelligence Briefing")
    skip_preflight = os.getenv("SKIP_PREFLIGHT", "").strip().lower() in {"1", "true", "yes"}

    try:
        if skip_preflight:
            print("INFO: SKIP_PREFLIGHT is enabled; skipping preflight Gemini call.")
        else:
            # Preflight to classify common operational failures early.
            run_preflight_check(client, model_ids)

        try:
            response = generate_with_fallback(client, model_ids, prompt, primary_cfg)
        except QuotaExceededError:
            print("WARN: Quota pressure detected, retrying with reduced token budget.")
            response = generate_with_fallback(client, model_ids, prompt, reduced_cfg)

        initial_text = getattr(response, "text", "") or ""
        pre_citation_words = estimate_word_count(initial_text)

        md_with_cites = add_citations_markdown(response)
        post_citation_words = estimate_word_count(md_with_cites)

        print(
            f"INFO: Briefing length diagnostics: pre_citation_words={pre_citation_words}, "
            f"post_citation_words={post_citation_words}, configured_cap={max_words}"
        )

        if pre_citation_words > max_words:
            print("WARN: Briefing exceeds max_words; requesting strict compression pass.")
            fallback_links = extract_markdown_links(md_with_cites)
            compression_prompt = build_compression_prompt(md_with_cites, max_words)
            compressed_response = generate_with_fallback(client, model_ids, compression_prompt, compression_cfg)
            compressed_text = getattr(compressed_response, "text", "") or ""
            compressed_text = ensure_citations_present(compressed_text, fallback_links)
            final_markdown = compressed_text
            post_compression_words = estimate_word_count(final_markdown)
            print(
                f"INFO: Post-compression words={post_compression_words}, configured_cap={max_words}"
            )

            if post_compression_words > max_words:
                strict_target_words = max(200, int(max_words * 0.95))
                print(
                    "WARN: First compression still above cap; running strict compression "
                    f"with lower target={strict_target_words}."
                )
                strict_prompt = build_compression_prompt(final_markdown, strict_target_words)
                strict_response = generate_with_fallback(client, model_ids, strict_prompt, compression_cfg)
                strict_text = getattr(strict_response, "text", "") or ""
                strict_text = ensure_citations_present(strict_text, fallback_links)
                final_markdown = strict_text
                post_compression_words = estimate_word_count(final_markdown)
                print(
                    f"INFO: Post-compression words={post_compression_words}, configured_cap={max_words}"
                )

                if post_compression_words > max_words:
                    diagnostics = {
                        "configured_cap": max_words,
                        "pre_citation_words": pre_citation_words,
                        "post_citation_words": post_citation_words,
                        "post_compression_words": post_compression_words,
                        "strict_target_words": strict_target_words,
                        "final_words": post_compression_words,
                    }
                    alert_subject = f"{subject_prefix} — length cap alert — {today_iso_utc()}"
                    alert_html = build_length_cap_alert_html(subject_prefix, diagnostics)
                    send_email(alert_subject, alert_html, smtp_user, recipients, smtp_password)
                    print("OK: length cap alert sent to recipients; briefing email suppressed.")
                    return
        else:
            final_markdown = md_with_cites
            print(f"INFO: Briefing within word cap ({pre_citation_words} <= {max_words}); no compression needed.")

        quality = meets_citation_threshold(final_markdown, citation_thresholds)
        print(
            "INFO: Citation-quality check "
            f"links={quality['unique_url_count']}/{quality['min_links']} "
            f"domains={quality['unique_domain_count']}/{quality['min_domains']} "
            f"passed={quality['threshold_passed']}"
        )

        # Citation quality check — informational only; never blocks sending.
        # grounding_chunks are frequently empty due to a confirmed Gemini API platform
        # bug (open as of early 2026), so inline link counts are an unreliable signal.
        # We surface a footer note when links are sparse, but do NOT retry generation
        # (retrying burns quota and cannot fix a server-side metadata bug).
        if not quality["threshold_passed"]:
            print(
                f"WARN: Citation quality below threshold "
                f"(links={quality['unique_url_count']}/{quality['min_links']}, "
                f"domains={quality['unique_domain_count']}/{quality['min_domains']}); "
                "sending briefing with footer note (known API grounding metadata limitation)."
            )
            footer_note = (
                f"⚠️ Grounding note: This briefing was generated with fewer verified source links than usual "
                f"({quality['unique_url_count']} links, {quality['unique_domain_count']} domains). "
                "Treat factual claims with extra scrutiny and verify independently. "
                "(Citation metadata from the Google Search grounding API is occasionally unavailable "
                "due to a known platform limitation — this does not indicate fabricated content.)"
            )
        else:
            footer_note = None

        html = markdown_to_html(final_markdown, footer_note=footer_note)

        subject = f"{subject_prefix} — {today_iso_utc()}"
        send_email(subject, html, smtp_user, recipients, smtp_password)
        print("OK: briefing sent.")
    except QuotaExceededError as e:
        # Graceful operational fallback: notify recipients but do not fail the workflow.
        alert_subject = f"{subject_prefix} — quota alert — {today_iso_utc()}"
        alert_html = build_quota_alert_html(subject_prefix, summarize_error(e))
        send_email(alert_subject, alert_html, smtp_user, recipients, smtp_password)
        print("OK: quota alert sent to recipients.")



if __name__ == "__main__":
    main()
